﻿$(document).ready(function () {
    $(".btnAddElement").click(function () {
	    $("body").append("<div class='newDiv'>New div</div>");
    });
    
})